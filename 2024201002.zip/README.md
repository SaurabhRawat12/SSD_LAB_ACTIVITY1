LAB ACTIVITY1 - SSD - LAB 1 -
Assumptions-
1. The additional files named "access.log" and "power_levels.txt" are in the same directory

Steps for execution of the files using terminal-
1. Type ./2024201002_q1.sh in the terminal where the current working directory contains the files.

