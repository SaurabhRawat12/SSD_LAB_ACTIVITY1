#!/bin/bash
awk '$9==404 && $6=="\"POST" {print $0}' access.log
